import React from 'react'

function Description() {
  return (
    <div className="center_wrapper">
      <h2> Description </h2>
        <div clasName="highlight_description">
        Mohsen Chavoshi Hosseini is an Iranian musician, singer, record producer and songwriter, based in Tehran. He has released ten albums including a soundtrack to the 2007 film Santouri.</div>
    </div>
  );
}

export default Description;
